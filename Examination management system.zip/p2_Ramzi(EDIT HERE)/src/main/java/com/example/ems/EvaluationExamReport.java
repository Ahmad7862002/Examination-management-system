/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.ems;

/**
 *
 * @author Kareem
 */
public class EvaluationExamReport {
    private final int examID;
    Exam exam;
    Question[] topQuestions;
    public EvaluationExamReport(Exam exam) {
        this.exam = exam;
        this.examID = exam.getExamID();
        updateEvaluationExamReport();
    }
    private void updateEvaluationExamReport() {
        Question[] questions = exam.getQuestions();
        topQuestions = new Question[Math.min(questions.length, 5)];
        for (int i = 0; i<questions.length-1; i++) {
            for (int j = 0; j < questions.length; j++) {
                if (questions[i].getEvaluationRank() < questions[i + 1].getEvaluationRank()) {
                    Question temp = questions[i];
                    questions[i] = questions[i + 1];
                    questions[i + 1] = temp;
                }
            }
        }
        for(int i = 0 ; i < 5 & i < questions.length ; i++) {
            topQuestions[i] = questions[i];
        }
    }
    
    public void getReport() {
        System.out.println("Now printing the hardest questions");
        printTopToughQuestions();
        System.out.println("Now printing all questions");
        printAllQuestions();
        System.out.println("Exam max grade         : " + exam.getMark());
        System.out.println("Exam code              : " + exam.getExamID());
        System.out.println("Exam duration          : " + exam.getDuration());
        System.out.println("Exam instructor's name : " + exam.getInstructorName());
        System.out.println("Exam histogram: ");
        exam.getStatisticalGraph().getHistogram();
    }
    
    public int getExamID() {
        return examID;
    }
    public Question[] getTopToughQuestions() {
        return topQuestions;
    }
    private void printAllQuestions() {
        Question[] questions = exam.getQuestions();
        for(int i=0; i<questions.length; i++) {
            questions[i].prettyPrintQuestion("X", i+1);
        }
    }
    private void printTopToughQuestions() {
        for(int i=0; i<topQuestions.length; i++) {
            System.out.println("Rank: " + topQuestions[i].getEvaluationRank() + ", Q#" + (i+1) + ": " + topQuestions[i].getQuestionText());
        }
    }

    public void setTopToughQuestions(Question[] topToughQuestions) {
        this.topQuestions = topToughQuestions;
    }
}
