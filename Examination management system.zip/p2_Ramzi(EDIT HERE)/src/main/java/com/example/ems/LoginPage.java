package com.example.ems;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;
import static com.example.ems.Main.*;
import java.util.ArrayList;
import java.util.List;


public class LoginPage {
    /*protected List<Student> studentList = new ArrayList<>();
    protected List<Instructor> instructorList = new ArrayList<>();
    protected List<Administrator> administratorList = new ArrayList<>();
    protected List<Exam> examList = new ArrayList<>();
    protected Course[] listOfCourses = {new Course("111", "Arch", "123", "atef")};
    protected boolean isLoggedIn = false;
    protected static int isLoggedInIndex = -1;
    protected boolean isAdmin = false;
    protected boolean isInstructor = false;*/

    public LoginPage() {

    }

    @FXML
    private Label label_infoWrong;
    @FXML
    private TextField tf_username;
    @FXML
    private PasswordField tf_password;
    @FXML
    private Button button_login;
    @FXML
    private Button button_toRegister;
    @FXML
    private Button button_exit;

    public void userLogin(ActionEvent event) throws IOException{
        checkLogin();
    }
    public void userExit(ActionEvent event) throws IOException {
        System.exit(0);
    }
    public void userRegister(ActionEvent event) throws IOException{

    }

    public void checkLogin() throws IOException{
        Main m = new Main();

        /*boolean isLoggedIn = false;
        int isLoggedInIndex = -1;
        boolean isAdmin = false;
        boolean isInstructor = false;*/

        /*List<Student> studentList = new ArrayList<>();
        List<Instructor> instructorList = new ArrayList<>();
        List<Administrator> administratorList = new ArrayList<>();
        List<Exam> examList = new ArrayList<>();
        Course[] listOfCourses = {new Course("111", "Arch", "123", "atef")};*/

        /*Student p1 = new Student("kareemramzi", "1", "Kareem Ramzi", "01004225312", "20P3845@eng.asu.edu.eg");
        Student p2 = new Student("ziadamerr", "a", "Ziad Amer", "01007130602", "20P5016@eng.asu.edu.eg");
        Student p3 = new Student("ahmadsameh", "qwerty", "Ahmad Sameh", "01022737486", "20P2914@eng.asu.edu.eg");
        Student p4 = new Student("ahmedashour", "asdfgh", "Ahmed Ashour", "01063939629", "20P4222@eng.asu.edu.eg");
        Student p5 = new Student("omarhisham", "abcd123", "Omar Hisham", "01063000222", "20P6484@eng.asu.edu.eg");
        Instructor i1 = new Instructor("atef", "a", "Mohamed Atef", "00000000000", "atef@eng.asu.edu.eg", 18, listOfCourses);
        Administrator a1 = new Administrator("mahmoudkhalil", "passx", "Mahmoud Khalil", "01001234567", "mahmoudkhalil@eng.asu.edu.eg");

        studentList.add(p1);
        studentList.add(p2);
        studentList.add(p3);
        studentList.add(p4);
        studentList.add(p5);
        instructorList.add(i1);
        administratorList.add(a1);*/

        if(!isLoggedIn) {
            for (int i = 0; i < studentList.size(); i++) {
                studentList.get(i).login(tf_username.getText().toString(), tf_password.getText().toString());
                if (studentList.get(i).isLoggedIn()) {
                    isLoggedIn = true;
                    isLoggedInIndex = i;
                    break;
                }
            }
            if (!isLoggedIn) {
                for (int i = 0; i < instructorList.size(); i++) {
                    instructorList.get(i).login(tf_username.getText().toString(), tf_password.getText().toString());
                    if (instructorList.get(i).isLoggedIn()) {
                        isLoggedIn = true;
                        isLoggedInIndex = i;
                        isInstructor = true;
                        break;

                    }
                }
                if (!isLoggedIn) {
                    for (int i = 0; i < administratorList.size(); i++) {
                        administratorList.get(i).login(tf_username.getText().toString(), tf_password.getText().toString());
                        if (administratorList.get(i).isLoggedIn()) {
                            isLoggedIn = true;
                            isLoggedInIndex = i;
                            isAdmin = true;
                            break;
                        }
                    }
                }
            }
            if (isLoggedIn) {
                //System.out.println("Successfully logged in");
                if(isInstructor){
                    m.changeScene("Instructor_Loggedin_Title.fxml");
                }else if(isAdmin){
                    m.changeScene("Admin_Loggedin_Title.fxml");
                }else{
                    m.changeScene("User_Loggedin_Title.fxml");
                }

            } else {
                if(tf_username.getText().toString().isEmpty() || tf_password.getText().toString().isEmpty()){
                    label_infoWrong.setText("Please input data in the fields");
                }else {
                    //System.out.println("Incorrect username or password");
                    label_infoWrong.setText("Incorrent username or password");
                }
            }
        } else {
            //System.out.println("You are already logged in");

        }
    }



}
