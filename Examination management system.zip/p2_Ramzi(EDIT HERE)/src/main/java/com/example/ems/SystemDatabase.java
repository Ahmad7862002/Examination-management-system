package com.example.ems;

public class SystemDatabase {
    public SystemDatabase(){

    }

}
